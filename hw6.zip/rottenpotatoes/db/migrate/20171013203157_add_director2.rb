class AddDirector2 < ActiveRecord::Migration
  def change
  end
end
